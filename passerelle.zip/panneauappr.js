'use strict';

// Exécutée dans la page des appréciations : un panneau d'affichage. Quand le curseur arrive dans la zone d'un élève,
// il montre son appréciation et la place dans le presse-papiers. C'est l'enseignant qui colle et qui enregistre :
// le panneau n'écrit jamais dans une zone. Sa seule action sur la page : refuser un collage qui n'est pas celui de l'élève.
function panneauAppreciations(eleves, periodeCarnet, reperesManquants) {
  const ID = 'passerelle-appreciations';
  const TABLE = '#table-saisie-appreciation';
  document.getElementById(ID)?.dispatchEvent(new Event('passerelle-fermer'));

  const nettoyer = (texte) => (texte || '').replace(/\s+/g, ' ').trim();
  const normal = (texte) => String(texte || '').replace(/\r\n?/g, '\n').trim();
  const textes = new Map(eleves.map((e) => [e.nom, e.texte]));
  const zonesPage = () => [...document.querySelectorAll(`${TABLE} tbody tr textarea`)];
  const nomDeZone = (z) => nettoyer(z.closest('tr')?.cells[0]?.innerText);
  const periodesPage = () => [
    ...new Set(
      [...document.querySelectorAll('button.dropdown-toggle')]
        .map((b) => nettoyer(b.innerText).match(/^(trimestre|semestre)\s*(\d)$/i))
        .filter(Boolean)
        .map((m) => m[1][0].toUpperCase() + m[2])
    ),
  ];
  const mauvaisePeriode = () => periodesPage().find((p) => p !== periodeCarnet);
  // Compteur « 0 / 250 » affiché par le site à côté de la zone.
  const limiteDe = (z) => Number(z.closest('td')?.innerText.match(/\d+\s*\/\s*(\d+)/)?.[1]) || null;

  const sombre = matchMedia('(prefers-color-scheme: dark)').matches;
  const couleurs = sombre
    ? { fond: '#1e1b1c', surface: '#2a2627', texte: '#f2eeef', texte2: '#b3aaad', accent: '#e0788a', ok: ['#17361f', '#93dfa8'], attention: ['#3a2f12', '#f0d27f'], bloque: ['#3f1b20', '#f6a5ae'] }
    : { fond: '#ffffff', surface: '#f6f3f4', texte: '#241f21', texte2: '#6a6265', accent: '#a0283c', ok: ['#e6f6ea', '#14622f'], attention: ['#fff5d6', '#6c4a00'], bloque: ['#fdeaea', '#a11a2b'] };

  const hote = document.createElement('div');
  hote.id = ID;
  const racine = hote.attachShadow({ mode: 'open' });
  // Un clic dans le panneau ne doit pas faire perdre le curseur à la zone de texte.
  hote.addEventListener('mousedown', (e) => {
    e.stopPropagation();
    e.preventDefault();
  });

  const creer = (balise, styles, texte) => {
    const el = document.createElement(balise);
    Object.assign(el.style, styles);
    // textContent uniquement : un texte de la page ou du carnet ne peut jamais être exécuté.
    if (texte !== undefined) el.textContent = texte;
    return el;
  };
  const boite = creer('div', {
    position: 'fixed', top: '12px', right: '12px', zIndex: '2147483647', width: '320px', maxHeight: '70vh',
    display: 'flex', flexDirection: 'column', overflow: 'hidden', background: couleurs.fond, color: couleurs.texte,
    borderRadius: '8px', font: "13px/1.45 'Segoe UI', system-ui, sans-serif", boxShadow: '0 4px 18px rgba(0,0,0,.25)',
  });
  const titre = creer('div', { padding: '8px 12px', fontSize: '14px', fontWeight: '600', color: '#ffffff', background: '#a0283c' }, `Appréciations ${periodeCarnet}`);
  const compteur = creer('div', { margin: '8px 12px 0', fontWeight: '600' });
  const alerte = creer('div', { margin: '8px 12px 0', padding: '6px 8px', borderRadius: '6px', fontWeight: '600', background: couleurs.bloque[0], color: couleurs.bloque[1] });
  alerte.hidden = true;
  const etat = creer('div', { margin: '8px 12px 0', padding: '6px 8px', borderRadius: '6px', fontWeight: '600' });
  const nom = creer('div', { margin: '8px 12px 0', fontWeight: '600' });
  const texte = creer('div', { margin: '4px 12px 0', padding: '6px 8px', overflowY: 'auto', flex: '1 1 auto', minHeight: '40px', whiteSpace: 'pre-wrap', borderRadius: '6px', background: couleurs.surface });
  const longueur = creer('div', { margin: '2px 12px 0', fontSize: '12px', color: couleurs.texte2 });
  const actions = creer('div', { display: 'flex', justifyContent: 'space-between', gap: '8px', padding: '6px 12px 10px' });
  const creerBouton = (libelle) => {
    const b = creer('button', { padding: '2px 4px', font: "12px 'Segoe UI', system-ui, sans-serif", color: couleurs.accent, background: 'transparent', border: '0', borderRadius: '4px', cursor: 'pointer' }, libelle);
    b.type = 'button';
    actions.append(b);
    return b;
  };
  const preparerBouton = creerBouton('Préparer ce texte');
  const coteBouton = creerBouton('Changer de côté');
  const fermerBouton = creerBouton('Fermer');
  preparerBouton.style.visibility = 'hidden';
  boite.append(titre, compteur, alerte, etat, nom, texte, longueur, actions);
  racine.append(boite);

  const montrerEtat = (niveau, message) => {
    etat.textContent = message;
    etat.style.background = couleurs[niveau][0];
    etat.style.color = couleurs[niveau][1];
  };
  const montrerAlerte = (message) => {
    alerte.textContent = message || '';
    alerte.hidden = !message;
    alerte.style.display = message ? '' : 'none';
  };
  const majCompteur = () => {
    const zones = zonesPage();
    const remplies = zones.filter((z) => z.value.trim() !== '').length;
    compteur.textContent = remplies === zones.length
      ? `${remplies} sur ${zones.length} : relis, puis clique sur Enregistrer`
      : `${remplies} sur ${zones.length} remplies`;
  };

  let zoneActive = null;
  let tour = 0;

  // Presse-papiers de la page, sinon commande de copie du navigateur (elle ne déplace pas le curseur).
  const ecrirePressePapiers = async (contenu) => {
    try {
      await navigator.clipboard.writeText(contenu);
      return;
    } catch {
      // On essaie l'autre méthode.
    }
    let fait = false;
    const surCopie = (e) => {
      e.clipboardData.setData('text/plain', contenu);
      e.preventDefault();
      e.stopImmediatePropagation();
      fait = true;
    };
    document.addEventListener('copy', surCopie, true);
    document.execCommand('copy');
    document.removeEventListener('copy', surCopie, true);
    if (!fait) throw new Error('Copie refusée');
  };

  const copier = async (zone, attendu) => {
    const ceTour = (tour += 1);
    // Jamais l'état de l'élève précédent pendant la copie.
    montrerEtat('attention', 'Préparation du texte…');
    try {
      await ecrirePressePapiers(attendu);
      if (ceTour !== tour) return;
      preparerBouton.style.visibility = 'hidden';
      montrerEtat('ok', 'Prêt : appuie sur Ctrl+V');
    } catch {
      if (ceTour !== tour) return;
      preparerBouton.style.visibility = 'visible';
      montrerEtat('attention', 'Texte pas encore prêt : clique sur « Préparer ce texte »');
    }
  };

  const suivreZone = (zone) => {
    zoneActive = zone;
    tour += 1;
    preparerBouton.style.visibility = 'hidden';
    const eleve = nomDeZone(zone);
    nom.textContent = eleve;
    const autre = mauvaisePeriode();
    if (autre) {
      texte.textContent = '';
      longueur.textContent = '';
      montrerEtat('bloque', `La page est sur ${autre}, le carnet sur ${periodeCarnet} : ne colle rien`);
      return;
    }
    if (!textes.has(eleve)) {
      texte.textContent = '';
      longueur.textContent = '';
      montrerEtat('bloque', 'Élève inconnu du carnet : ne colle rien');
      return;
    }
    const attendu = textes.get(eleve);
    texte.textContent = attendu;
    const limite = limiteDe(zone);
    longueur.textContent = limite ? `${attendu.length} / ${limite} caractères` : `${attendu.length} caractères`;
    if (limite && attendu.length > limite) {
      montrerEtat('bloque', `Trop long pour École Directe : raccourcis ce texte dans le Carnet`);
    } else if (normal(zone.value) === normal(attendu) && attendu) {
      montrerEtat('ok', 'Collé : relis, puis appuie sur Entrée');
    } else if (zone.value.trim()) {
      montrerEtat('attention', 'Cette case contient déjà un texte : rien n’est préparé');
    } else if (!attendu) {
      montrerEtat('attention', 'Pas d’appréciation dans le carnet pour cet élève');
    } else {
      copier(zone, attendu);
    }
  };

  const surFocus = (e) => {
    const zone = e.target.closest?.(`${TABLE} textarea`);
    if (zone) suivreZone(zone);
  };

  // Seule intervention sur la page : refuser un collage qui n'est pas le texte de cet élève ou qui s'ajouterait à un texte.
  const surCollage = (e) => {
    const zone = e.target.closest?.(`${TABLE} textarea`);
    if (!zone) return;
    const eleve = nomDeZone(zone);
    const attendu = textes.get(eleve);
    const colle = normal(e.clipboardData?.getData('text'));
    let refus = '';
    if (mauvaisePeriode()) refus = 'Collage refusé : ce n’est pas la bonne période';
    else if (attendu === undefined) refus = 'Collage refusé : élève inconnu du carnet';
    else if (limiteDe(zone) && attendu.length > limiteDe(zone)) refus = 'Collage refusé : texte trop long pour École Directe';
    else if (zone.value.trim()) refus = 'Collage refusé : cette case contient déjà un texte';
    else if (colle !== normal(attendu)) refus = 'Collage refusé : ce n’est pas le texte de cet élève';
    if (refus) {
      e.preventDefault();
      e.stopImmediatePropagation();
      zoneActive = zone;
      nom.textContent = eleve;
      montrerEtat('bloque', refus);
      return;
    }
    setTimeout(() => {
      majCompteur();
      montrerEtat('ok', 'Collé : relis, puis appuie sur Entrée');
    }, 0);
    // Le bouton Enregistrer de la page s'active quand une zone change : sinon, le site n'a pas vu le collage.
    setTimeout(() => {
      if (document.querySelector('#btn-bas-enregistrer')?.disabled) {
        montrerAlerte('Mettre à jour l’extension : École Directe a changé (enregistrer)');
      }
    }, 600);
  };

  document.addEventListener('focusin', surFocus, true);
  document.addEventListener('paste', surCollage, true);
  document.addEventListener('input', majCompteur, true);

  const retirer = () => {
    document.removeEventListener('focusin', surFocus, true);
    document.removeEventListener('paste', surCollage, true);
    document.removeEventListener('input', majCompteur, true);
    hote.remove();
  };
  hote.addEventListener('passerelle-fermer', retirer);

  preparerBouton.addEventListener('click', () => {
    if (zoneActive) copier(zoneActive, textes.get(nomDeZone(zoneActive)) || '');
  });
  let aDroite = true;
  coteBouton.addEventListener('click', () => {
    aDroite = !aDroite;
    boite.style.right = aDroite ? '12px' : 'auto';
    boite.style.left = aDroite ? 'auto' : '12px';
  });
  // En partant, aucune appréciation ne reste dans le presse-papiers.
  fermerBouton.addEventListener('click', () => {
    ecrirePressePapiers(' ').catch(() => {});
    retirer();
  });

  montrerAlerte(reperesManquants.length ? `Mettre à jour l’extension : École Directe a changé (${reperesManquants.join(', ')})` : '');
  montrerEtat('attention', 'Clique dans la zone du premier élève');
  majCompteur();
  document.documentElement.append(hote);
}
