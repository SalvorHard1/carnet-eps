// Lecture seule : ce script n'écrit rien dans la page, ne clique sur rien et ne communique
// avec rien. Sur demande, il fait seulement défiler la grille pour que toutes les lignes se
// chargent, puis la remet à sa position. Il lit les noms des élèves pour les afficher dans
// la fenêtre de l'extension, et ne lit jamais les notes.
(async () => {
  'use strict';

  const MAX_PAS = 300;
  const ATTENTE_MS = 150;

  const nettoyer = (texte) => (texte || '').replace(/\s+/g, ' ').trim();
  const CODES_NOTE = /^\(?(abs|disp|ne|nn)\)?$/i;
  const ressembleANom = (texte) => /\p{L}{2,}/u.test(texte) && !CODES_NOTE.test(texte);
  const attendre = (ms) => new Promise((fin) => setTimeout(fin, ms));

  // Forme anonyme d'un nom : « DUPONT Jean-Luc » devient « A A-A ».
  const forme = (texte) => texte.replace(/\p{L}+/gu, 'A').replace(/\d+/g, '9');

  // Cherche le nom dans une ligne : d'abord les en-têtes de ligne, puis, uniquement dans
  // les colonnes figées (hors tableau principal), la première cellule contenant des lettres.
  // Nom coupé à l'écran (« Etien… ») : le nom complet est parfois dans une info-bulle.
  const COUPE = /…|\.{3}/;
  const texteComplet = (cellule) => {
    const texte = nettoyer(cellule.innerText);
    if (!COUPE.test(texte)) return texte;
    // L'info-bulle doit commencer comme le texte affiché (même premier mot) : sinon ce n'est pas le nom.
    const debut = texte.split(/[\s…]/)[0].toLocaleLowerCase('fr');
    const bulle = [cellule, ...cellule.querySelectorAll('[title]')]
      .map((el) => nettoyer(el.getAttribute('title')))
      .find((t) => ressembleANom(t) && !COUPE.test(t) && debut.length > 1 && t.toLocaleLowerCase('fr').startsWith(debut));
    return bulle || texte;
  };
  const lireNom = (ligne) => {
    for (const th of ligne.querySelectorAll('th, [role="rowheader"]')) {
      const texte = texteComplet(th);
      if (ressembleANom(texte)) return { nom: texte, source: 'th' };
    }
    if (!ligne.closest('.ht_master')) {
      for (const td of ligne.querySelectorAll('td')) {
        const texte = texteComplet(td);
        if (ressembleANom(texte)) return { nom: texte, source: 'td' };
      }
    }
    return { nom: '', source: '' };
  };

  const grilles = [...document.querySelectorAll('[role="treegrid"].handsontable')];
  const grille = grilles.length === 1 ? grilles[0] : null;

  const parIndex = new Map();
  const indexEnTetes = new Set();
  const lignesSansIndex = new Set();
  const indexEnConflit = new Set();

  const relever = () => {
    for (const ligne of grille.querySelectorAll('tr')) {
      const index = ligne.getAttribute('aria-rowindex');
      if (ligne.closest('thead')) {
        if (index) indexEnTetes.add(index);
        continue;
      }
      if (!index) {
        lignesSansIndex.add(ligne);
        continue;
      }
      // Une même ligne est répétée dans les colonnes figées : on fusionne par numéro de ligne.
      const { nom, source } = lireNom(ligne);
      const existant = parIndex.get(index);
      if (!existant) {
        parIndex.set(index, { nom, source });
      } else if (nom && !existant.nom) {
        existant.nom = nom;
        existant.source = source;
      } else if (nom && existant.nom && nom !== existant.nom) {
        indexEnConflit.add(index);
      }
    }
  };

  // Le conteneur qui défile : la grille elle-même, un de ses parents, ou la page.
  const trouverDefilant = () => {
    const depart = grille.querySelector('.ht_master .wtHolder') || grille;
    for (let el = depart; el && el !== document.body; el = el.parentElement) {
      const defilement = getComputedStyle(el).overflowY;
      if (
        (defilement === 'auto' || defilement === 'scroll') &&
        el.scrollHeight > el.clientHeight + 1
      ) {
        return { element: el, nature: el === depart ? 'grille' : 'parent' };
      }
    }
    return { element: document.scrollingElement, nature: 'page' };
  };

  const parcourir = async () => {
    const { element, nature } = trouverDefilant();
    const positionInitiale = element.scrollTop;
    let finAtteinte = false;
    let pas = 0;

    try {
      element.scrollTop = 0;
      await attendre(ATTENTE_MS);
      for (; pas < MAX_PAS; pas += 1) {
        relever();
        if (element.scrollTop + element.clientHeight >= element.scrollHeight - 2) {
          finAtteinte = true;
          break;
        }
        const avant = element.scrollTop;
        // Avance de moins d'un écran : chaque ligne est vue au moins une fois.
        element.scrollTop = avant + Math.max(20, Math.floor(element.clientHeight * 0.7));
        await attendre(ATTENTE_MS);
        if (element.scrollTop === avant) break;
      }
    } finally {
      element.scrollTop = positionInitiale;
    }
    return { finAtteinte, pas, nature };
  };

  const parcours = grille ? await parcourir() : { finAtteinte: false, pas: 0, nature: '' };

  const lignes = [...parIndex.entries()]
    .sort((a, b) => Number(a[0]) - Number(b[0]))
    .map(([index, ligne]) => ({ index: Number(index), nom: ligne.nom, source: ligne.source }));

  const sources = { th: 0, td: 0 };
  for (const ligne of lignes) {
    if (ligne.source) sources[ligne.source] += 1;
  }

  const nomsVus = new Map();
  for (const { nom } of lignes) {
    if (nom) {
      const cle = nom.toLocaleLowerCase('fr');
      nomsVus.set(cle, (nomsVus.get(cle) || 0) + 1);
    }
  }
  const sansNom = lignes.filter((l) => !l.nom).length;
  const doublons = [...nomsVus.values()].filter((n) => n > 1).length;
  const trous = lignes.filter((l, i) => i > 0 && l.index !== lignes[i - 1].index + 1).length;
  const conflits = indexEnConflit.size;
  const sansIndex = lignesSansIndex.size;

  // Sans les premières lignes, la lecture n'est pas fiable : le numéro de la première ligne
  // doit suivre directement celui du dernier en-tête.
  const dernierEnTete = Math.max(0, ...[...indexEnTetes].map(Number));
  const debutManquant = lignes.length > 0 && lignes[0].index !== dernierEnTete + 1;

  const alertes = [];
  if (grilles.length > 1) alertes.push(`${grilles.length} grilles sur la page : analyse arrêtée.`);
  if (grille && !parcours.finAtteinte) alertes.push("Le bas de la grille n'a pas été atteint.");
  if (debutManquant) alertes.push('Le début de la liste semble manquer.');
  if (sansNom) alertes.push(`${sansNom} ligne(s) sans nom détecté.`);
  if (doublons) alertes.push(`${doublons} nom(s) présent(s) plusieurs fois.`);
  if (conflits) alertes.push(`${conflits} ligne(s) avec deux noms différents.`);
  if (trous) alertes.push(`${trous} interruption(s) dans la numérotation des lignes.`);
  if (sansIndex) alertes.push(`${sansIndex} ligne(s) sans numéro ignorée(s).`);

  let verdict;
  if (!lignes.length) {
    verdict = { niveau: 'bloque', texte: 'Aucune grille lisible : ne pas continuer.' };
  } else if (alertes.length) {
    verdict = { niveau: 'attention', texte: 'Lecture incomplète ou incertaine : voir ci-dessous.' };
  } else {
    verdict = { niveau: 'ok', texte: 'Grille parcourue : compare les noms avec ta liste.' };
  }

  // Repères de la page dont l'extension a besoin : s'il en manque un, École Directe a sans doute changé.
  const reperes = [];
  if (grille) {
    const entetes = [...grille.querySelectorAll('thead th')];
    if (!entetes.some((th) => th.hasAttribute('aria-colindex'))) reperes.push('colonnes');
    if (!grille.querySelector('td[aria-colindex]')) reperes.push('cases');
    if (!grille.querySelector('button[data-action][data-row]')) reperes.push('crayon');
    // Seul le motif « /20 » est cherché ; le texte de l'en-tête n'est pas conservé.
    if (!entetes.some((th) => /(?:^|[^\d])\/\s*\d/.test(th.innerText || ''))) reperes.push('bareme');
  } else if (document.querySelector('.handsontable')) {
    reperes.push('grille');
  }

  // Diagnostic anonyme : uniquement des comptages et la forme des noms, jamais leur contenu.
  const premierNom = lignes.find((l) => l.nom);
  const technique = {
    cadre: window === window.top ? 'principal' : 'secondaire',
    grilles: grilles.length,
    enTetes: indexEnTetes.size,
    lignes: lignes.length,
    fin: parcours.finAtteinte,
    pas: parcours.pas,
    defilement: parcours.nature,
    debutManquant,
    sansNom,
    doublons,
    conflits,
    trous,
    sansIndex,
    sources,
    forme: premierNom ? forme(premierNom.nom) : '',
    reperes,
  };

  return { verdict, lignes, finAtteinte: parcours.finAtteinte, alertes, technique };
})();
