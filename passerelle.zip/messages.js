'use strict';

// Écran « Messages » de la fenêtre : modèles proposés d'après l'objet, ou choisis par thème.
// (ajouter, zone et ecrirePressePapiers viennent de popup.js ; les modèles de modeles.js.)
// Seuls la signature et le format choisi sont retenus ; les cases remplies sont oubliées à la fermeture.

const memoire = {
  lire(cle, defaut) {
    try {
      return localStorage.getItem(`passerelle-${cle}`) ?? defaut;
    } catch {
      return defaut;
    }
  },
  ecrire(cle, valeur) {
    try {
      localStorage.setItem(`passerelle-${cle}`, valeur);
    } catch {
      // Sans mémoire, la fenêtre marche quand même : la signature sera simplement à retaper.
    }
  },
};

async function lireObjet(onglet) {
  if (!onglet) return null;
  try {
    const retours = await chrome.scripting.executeScript({
      target: { tabId: onglet.id, allFrames: true },
      files: ['lectureobjet.js'],
    });
    const lectures = retours.map((x) => x.result).filter(Boolean);
    return lectures.find((l) => l.champ) || lectures[0] || null;
  } catch {
    return null;
  }
}

function afficherMessages(lecture) {
  zone.replaceChildren();
  if (lecture?.messagerie && !lecture.champ) {
    ajouter(zone, 'p', 'Mettre à jour l’extension : École Directe a changé (objet)', 'verdict bloque');
  }

  const cartesModeles = [];
  const marquer = (id) => cartesModeles.forEach(([carte, idCarte]) => carte.setAttribute('aria-pressed', String(idCarte === id)));
  const choisir = (theme, modele) => {
    liste.value = modele.id;
    marquer(modele.id);
    afficherModele(detail, theme, modele);
  };

  const suggestions = lecture?.objet ? suggererModeles(lecture.objet) : [];
  if (lecture?.objet) {
    ajouter(zone, 'p', `Objet : « ${lecture.objet} »`, 'compte');
    if (suggestions.length) {
      ajouter(zone, 'h2', 'Proposés pour cet objet');
      const cartes = ajouter(zone, 'div', undefined, 'propositions');
      for (const { theme, modele } of suggestions) {
        const carte = ajouter(cartes, 'button', undefined, 'proposition');
        carte.type = 'button';
        ajouter(carte, 'span', modele.titre, 'proposition-titre');
        ajouter(carte, 'span', theme.nom, 'proposition-theme');
        carte.addEventListener('click', () => choisir(theme, modele));
        cartesModeles.push([carte, modele.id]);
      }
    } else {
      ajouter(zone, 'p', 'Aucun modèle pour cet objet : choisis un thème', 'verdict attention');
    }
  } else if (lecture?.champ) {
    ajouter(zone, 'p', 'Tape l’objet dans École Directe, puis reclique sur l’icône. Ou choisis un thème :', 'compte');
  }

  ajouter(zone, 'h2', suggestions.length ? 'Ou un autre thème' : 'Choisir un thème');
  const liste = ajouter(zone, 'select', undefined, 'themes');
  liste.setAttribute('aria-label', 'Choisir un modèle');
  const vide = ajouter(liste, 'option', 'Choisir un modèle…');
  vide.value = '';
  for (const theme of THEMES_MESSAGES) {
    const groupe = ajouter(liste, 'optgroup');
    groupe.label = theme.nom;
    for (const modele of theme.modeles) ajouter(groupe, 'option', modele.titre).value = modele.id;
  }
  const detail = ajouter(zone, 'div', undefined, 'detail');
  liste.addEventListener('change', () => {
    const trouve = trouverModele(liste.value);
    marquer(liste.value);
    if (trouve) afficherModele(detail, trouve.theme, trouve.modele);
    else detail.replaceChildren();
  });

  if (suggestions.length) choisir(suggestions[0].theme, suggestions[0].modele);
}

function afficherModele(detail, theme, modele) {
  detail.replaceChildren();
  const valeurs = {};
  let format = memoire.lire('format', 'mail') === 'mot' ? 'mot' : 'mail';

  // Mail ou mot dans le carnet de correspondance.
  const bascule = ajouter(detail, 'div', undefined, 'bascule');
  bascule.setAttribute('role', 'group');
  bascule.setAttribute('aria-label', 'Format');
  const formats = { mail: 'Mail', mot: 'Mot dans le carnet' };
  const boutonsFormat = {};
  for (const [cle, nom] of Object.entries(formats)) {
    const b = ajouter(bascule, 'button', nom);
    b.type = 'button';
    b.addEventListener('click', () => {
      format = cle;
      memoire.ecrire('format', cle);
      rendre();
    });
    boutonsFormat[cle] = b;
  }

  const blocObjet = ajouter(detail, 'div', undefined, 'bloc-objet');
  ajouter(blocObjet, 'h2', 'Objet');
  const ligneObjet = ajouter(blocObjet, 'div', undefined, 'ligne-objet');
  const texteObjet = ajouter(ligneObjet, 'span', undefined, 'texte-objet');
  const copierObjet = ajouter(ligneObjet, 'button', 'Copier');
  copierObjet.type = 'button';
  copierObjet.setAttribute('aria-label', 'Copier l’objet');

  const cases = casesDuModele(modele.objet, modele.mail, modele.mot);
  const blocCases = ajouter(detail, 'div', undefined, 'cases');
  if (cases.length) ajouter(blocCases, 'h2', 'À compléter');
  const champs = {};
  for (const nom of cases) {
    const etiquette = ajouter(blocCases, 'label', undefined, 'case');
    ajouter(etiquette, 'span', nom);
    const champ = ajouter(etiquette, 'input');
    champ.type = 'text';
    champ.autocomplete = 'off';
    champ.spellcheck = true;
    champ.addEventListener('input', () => {
      valeurs[nom] = champ.value;
      rendre();
    });
    champs[nom] = { etiquette, champ };
  }

  ajouter(detail, 'h2', 'Message');
  const apercu = ajouter(detail, 'pre', undefined, 'apercu');
  const etat = ajouter(detail, 'p', undefined, 'etat');
  const copierMessage = ajouter(detail, 'button', 'Copier le message', 'principal');
  copierMessage.type = 'button';

  const reglages = ajouter(detail, 'details', undefined, 'reglages');
  ajouter(reglages, 'summary', 'Signature');
  const signature = ajouter(reglages, 'textarea');
  signature.rows = 2;
  signature.placeholder = 'Ex. : M. Dupont, professeur d’EPS';
  signature.value = memoire.lire('signature', '');
  signature.addEventListener('input', () => {
    memoire.ecrire('signature', signature.value);
    rendre();
  });

  const texteFinal = () => {
    const corps = remplirModele(format === 'mot' ? modele.mot : modele.mail, valeurs);
    const signe = signature.value.trim();
    return signe ? `${corps}\n${format === 'mot' ? '' : '\n'}${signe}` : corps;
  };
  const restantes = () => casesDuModele(format === 'mot' ? '' : modele.objet, format === 'mot' ? modele.mot : modele.mail).filter((n) => !(valeurs[n] || '').trim());

  function rendre() {
    for (const [cle, b] of Object.entries(boutonsFormat)) b.setAttribute('aria-pressed', String(cle === format));
    blocObjet.hidden = format === 'mot';
    texteObjet.textContent = remplirModele(modele.objet, valeurs);
    // Seules les cases utiles au format choisi restent visibles.
    const utiles = casesDuModele(format === 'mot' ? '' : modele.objet, format === 'mot' ? modele.mot : modele.mail);
    for (const [nom, { etiquette }] of Object.entries(champs)) etiquette.hidden = !utiles.includes(nom);
    blocCases.hidden = !utiles.length;
    apercu.textContent = texteFinal();
    const reste = restantes();
    etat.textContent = reste.length ? `Reste à compléter : ${reste.join(', ')}` : '';
    etat.className = reste.length ? 'etat verdict attention' : 'etat';
  }

  const copier = async (bouton, texte, apres) => {
    const libelle = bouton.textContent;
    try {
      await ecrirePressePapiers(texte);
      bouton.textContent = 'Copié';
      etat.textContent = apres;
      etat.className = 'etat verdict ok';
    } catch {
      bouton.textContent = 'Copie impossible';
    }
    setTimeout(() => {
      bouton.textContent = libelle;
    }, 1600);
  };
  copierObjet.addEventListener('click', () => copier(copierObjet, texteObjet.textContent, 'Objet copié : clique dans le champ Objet, puis Ctrl+V'));
  copierMessage.addEventListener('click', () => {
    const reste = restantes();
    const suite = reste.length ? ` (encore entre crochets : ${reste.join(', ')})` : '';
    const ou = format === 'mot' ? 'dans le mot' : 'dans le message';
    copier(copierMessage, texteFinal(), `Message copié : clique ${ou}, puis Ctrl+V${suite}`);
  });

  rendre();
  const premier = cases.map((n) => champs[n]).find((c) => !c.etiquette.hidden);
  premier?.champ.focus();
}
