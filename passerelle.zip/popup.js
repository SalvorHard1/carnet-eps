'use strict';

// (lireExportCarnet et rapprocher viennent de rapprochement.js, chargé juste avant.)
const bouton = document.getElementById('relancer');
const boutonVider = document.getElementById('vider');
const boutonMessages = document.getElementById('messages');
const zone = document.getElementById('resultat');

function ajouter(parent, balise, texte, classe) {
  const el = document.createElement(balise);
  // textContent uniquement : un texte venant de la page ne peut jamais être exécuté.
  if (texte !== undefined) el.textContent = texte;
  if (classe) el.className = classe;
  parent.appendChild(el);
  return el;
}

function afficherMessage(texte, niveau) {
  zone.replaceChildren();
  ajouter(zone, 'p', texte, `verdict ${niveau}`);
}

function estEcoleDirecte(adresse) {
  try {
    const url = new URL(adresse);
    return (
      url.protocol === 'https:' &&
      (url.hostname === 'ecoledirecte.com' || url.hostname.endsWith('.ecoledirecte.com'))
    );
  } catch {
    return false;
  }
}

function texteTechnique(t) {
  return [
    `cadre=${t.cadre} grilles=${t.grilles} entetes=${t.enTetes} defilement=${t.defilement || '?'}`,
    `lignes=${t.lignes} fin=${t.fin ? 'oui' : 'non'} pas=${t.pas} debutmanquant=${t.debutManquant ? 'oui' : 'non'}`,
    `sansnom=${t.sansNom} doublons=${t.doublons} conflits=${t.conflits} trous=${t.trous} sansindex=${t.sansIndex}`,
    `th=${t.sources.th} td=${t.sources.td} forme=${t.forme || 'aucune'}`,
  ].join('\n');
}

function ajouterEtapesDepart(etapes, premier) {
  ajouter(etapes, 'li', 'Clique sur le crayon du devoir');
  ajouter(etapes, 'li', `Désélectionne la case (Échap), puis clique une fois sur celle de ${premier}`);
}

// Repères absents de la page : le travail reste possible, mais le guide ne suivra plus.
function ajouterAlerteMiseAJour(lecture) {
  const manquants = lecture.technique?.reperes || [];
  if (manquants.length) {
    ajouter(zone, 'p', `Mettre à jour l'extension : École Directe a changé (${manquants.join(', ')})`, 'verdict bloque');
  }
}

function afficherPret(r, carnet, lecture) {
  zone.replaceChildren();
  ajouterAlerteMiseAJour(lecture);
  ajouter(zone, 'p', `${carnet.classe} : ${r.nombre} élèves sur ${r.nombre}`, 'verdict ok');
  ajouter(zone, 'p', `${carnet.evaluation}, sur ${carnet.max}`, 'compte');

  const etapes = ajouter(zone, 'ol');
  ajouterEtapesDepart(etapes, r.premier);
  ajouter(etapes, 'li', 'Ctrl+V, puis vérifie');
  if (r.aCompleter.length) ajouter(etapes, 'li', 'Tape les codes');
  ajouter(etapes, 'li', 'Enregistrer');

  if (r.vides) ajouter(zone, 'p', `${r.vides} sans note : case vidée au collage`, 'verdict attention');
  if (r.aCompleter.length) {
    ajouter(zone, 'h2', 'Codes à taper');
    const liste = ajouter(zone, 'ul', undefined, 'liste-codes');
    r.aCompleter.forEach((c) => ajouter(liste, 'li', `${c.touche} : ${c.nom}`));
  }
}

function afficherEffacement(r, lecture) {
  zone.replaceChildren();
  ajouterAlerteMiseAJour(lecture);
  ajouter(zone, 'p', `Effacement prêt : ${r.nombre} cases`, 'verdict attention');
  const etapes = ajouter(zone, 'ol');
  ajouterEtapesDepart(etapes, r.premier);
  ajouter(etapes, 'li', 'Ctrl+V : toute la colonne se vide');
  ajouter(etapes, 'li', 'Enregistrer, ou recharge la page pour annuler');
}

// Exécutée dans la page : un simple panneau d'affichage, qui ne touche ni à la grille ni aux notes.
function panneauCodes(codes, carnet, premierIndex, reperesManquants) {
  const ID = 'notes-vers-ecole-directe';
  document.getElementById(ID)?.remove();
  const hote = document.createElement('div');
  hote.id = ID;
  const racine = hote.attachShadow({ mode: 'open' });
  // Un clic dans le panneau ne doit pas désélectionner la case de la grille.
  hote.addEventListener('mousedown', (e) => {
    e.stopPropagation();
    e.preventDefault();
  });
  // Mêmes couleurs que la fenêtre de l'extension (popup.css), en clair et en sombre.
  const sombre = matchMedia('(prefers-color-scheme: dark)').matches;
  const couleurs = sombre
    ? {
        fond: '#1e1b1c',
        texte: '#f2eeef',
        accent: '#e0788a',
        ok: ['#17361f', '#93dfa8'],
        attention: ['#3a2f12', '#f0d27f'],
        bloque: ['#3f1b20', '#f6a5ae'],
      }
    : {
        fond: '#ffffff',
        texte: '#241f21',
        accent: '#a0283c',
        ok: ['#e6f6ea', '#14622f'],
        attention: ['#fff5d6', '#6c4a00'],
        bloque: ['#fdeaea', '#a11a2b'],
      };
  const boite = document.createElement('div');
  const placer = (droite) => {
    boite.style.right = droite ? '12px' : 'auto';
    boite.style.left = droite ? 'auto' : '12px';
  };
  Object.assign(boite.style, {
    position: 'fixed',
    top: '12px',
    zIndex: '2147483647',
    width: '250px',
    maxHeight: '60vh',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    background: couleurs.fond,
    color: couleurs.texte,
    borderRadius: '8px',
    font: "13px/1.45 'Segoe UI', system-ui, sans-serif",
    boxShadow: '0 4px 18px rgba(0,0,0,.25)',
  });
  placer(true);

  const titre = document.createElement('div');
  // Sans carnet : guide de « Vider la colonne », sans barème à comparer.
  titre.textContent = !carnet ? 'Vider la colonne' : codes.length ? 'Codes à taper' : 'Vérifie la colonne';
  Object.assign(titre.style, {
    padding: '8px 12px',
    fontSize: '14px',
    fontWeight: '600',
    color: '#ffffff',
    background: '#a0283c',
  });

  // Contrôle en direct : le barème de la colonne sélectionnée doit être celui du carnet.
  const controle = document.createElement('div');
  Object.assign(controle.style, {
    margin: '10px 12px 0',
    padding: '6px 8px',
    borderRadius: '6px',
    fontWeight: '600',
  });
  const baremeCarnet = carnet ? Number(String(carnet.max).replace(',', '.')) : null;
  // Colonne de la dernière case cliquée, si la page ne marque pas la case sélectionnée.
  // Oublié dès qu'on clique ailleurs ou qu'on se déplace au clavier : jamais de vert périmé.
  let colonneCliquee = null;
  const noterClic = (e) => {
    if (e.target === hote) return;
    const cellule = e.target.closest?.('[role="treegrid"].handsontable td');
    colonneCliquee = cellule ? cellule.getAttribute('aria-colindex') : null;
  };
  const oublierClic = (e) => {
    if (/^(Arrow|Page|Tab$|Enter$|Home$|End$)/.test(e.key)) colonneCliquee = null;
  };
  document.addEventListener('mousedown', noterClic, true);
  document.addEventListener('keydown', oublierClic, true);
  const lireColonne = () => {
    const grille = document.querySelector('[role="treegrid"].handsontable');
    if (!grille) return null;
    // Seulement `current` : `aria-selected` marque aussi d'autres cases, parfois d'une autre colonne.
    const cellule = grille.querySelector('td.current');
    const numero = cellule ? cellule.getAttribute('aria-colindex') : colonneCliquee;
    if (!cellule && !numero) return null;
    const entetes = numero
      ? [...grille.querySelectorAll(`thead th[aria-colindex="${CSS.escape(numero)}"]`)]
      : [...grille.querySelectorAll('thead tr')].map((tr) => tr.children[cellule.cellIndex]).filter(Boolean);
    for (const entete of entetes) {
      const texte = entete.innerText || '';
      // « /20 » mais pas la date « 07/11/26 » : pas de chiffre juste avant la barre.
      const trouves = [...texte.matchAll(/(?:^|[^\d])\/\s*(\d+(?:[.,]\d+)?)/g)];
      if (trouves.length) {
        return {
          titre: texte.split('\n').map((l) => l.trim()).find(Boolean) || 'Ce devoir',
          bareme: Number(trouves[trouves.length - 1][1].replace(',', '.')),
        };
      }
    }
    return { titre: '', bareme: null };
  };
  let messageAffiche = null;
  const majControle = () => {
    const colonne = lireColonne();
    let message = carnet ? `${carnet.evaluation}, sur ${carnet.max}` : 'Choisis la colonne à vider';
    let niveau = 'attention';
    if (!carnet) {
      if (colonne) {
        message = colonne.bareme === null ? 'Colonne à vider : vérifie-la toi-même' : `Colonne à vider : ${colonne.titre}, sur ${colonne.bareme}`;
      }
    } else if (colonne && colonne.bareme === null) {
      message = 'Barème non lu : vérifie la colonne toi-même';
    } else if (colonne && colonne.bareme !== baremeCarnet) {
      message = `Mauvaise colonne : ${colonne.titre} est sur ${colonne.bareme}, le carnet sur ${carnet.max}`;
      niveau = 'bloque';
    } else if (colonne) {
      message = `Barème bon : ${colonne.titre}, sur ${colonne.bareme}`;
      niveau = 'ok';
    }
    const cle = `${niveau}|${message}`;
    if (cle === messageAffiche) return;
    messageAffiche = cle;
    controle.textContent = message;
    [controle.style.background, controle.style.color] = couleurs[niveau];
  };

  // Guide à l'écran, comme l'aide du Carnet : un anneau et une bulle qui laissent passer les clics.
  // Il regarde la page et avance quand l'enseignant fait le geste ; il ne clique et n'écrit rien.
  const consigne = document.createElement('div');
  Object.assign(consigne.style, { margin: '8px 12px 0', fontWeight: '600', color: couleurs.accent });

  // École Directe a changé : un repère manque, ou un geste n'a rien produit sur la page.
  const alerte = document.createElement('div');
  Object.assign(alerte.style, {
    display: 'none',
    margin: '8px 12px 0',
    padding: '6px 8px',
    borderRadius: '6px',
    fontWeight: '600',
    background: couleurs.bloque[0],
    color: couleurs.bloque[1],
  });
  const manquants = new Set(reperesManquants);
  const majAlerte = () => {
    if (!manquants.size) return;
    alerte.textContent = `Mettre à jour l'extension : École Directe a changé (${[...manquants].join(', ')})`;
    alerte.style.display = 'block';
  };
  const signaler = (repere) => {
    manquants.add(repere);
    majAlerte();
  };
  majAlerte();

  const anneau = document.createElement('div');
  Object.assign(anneau.style, {
    position: 'fixed',
    zIndex: '2147483646',
    pointerEvents: 'none',
    border: '3px solid #a0283c',
    borderRadius: '6px',
    boxShadow: '0 0 0 3px rgba(160,40,60,.25)',
    display: 'none',
  });
  const bulle = document.createElement('div');
  Object.assign(bulle.style, {
    position: 'fixed',
    zIndex: '2147483646',
    pointerEvents: 'none',
    maxWidth: '220px',
    padding: '5px 9px',
    color: '#ffffff',
    background: '#a0283c',
    borderRadius: '6px',
    font: "600 12px/1.35 'Segoe UI', system-ui, sans-serif",
    display: 'none',
  });
  racine.append(anneau, bulle);

  const guide = { etape: 1, code: 0, colle: false, boutonEnregistrer: null };
  const grilleNotes = () => document.querySelector('[role="treegrid"].handsontable');
  const visible = (el) => {
    const zone = el.getBoundingClientRect();
    return zone.width > 0 && zone.height > 0;
  };
  const colonneOuverte = () => grilleNotes()?.querySelector('td.writable')?.getAttribute('aria-colindex') || null;
  const caseEleve = (index, colonne) =>
    colonne
      ? [...grilleNotes().querySelectorAll(`tr[aria-rowindex="${index}"] td[aria-colindex="${CSS.escape(colonne)}"]`)].find(visible) || null
      : null;
  const estSelectionnee = (index, colonne) => {
    const cellule = grilleNotes()?.querySelector('td.current');
    return Boolean(
      cellule &&
        cellule.getAttribute('aria-colindex') === colonne &&
        cellule.closest('tr')?.getAttribute('aria-rowindex') === String(index)
    );
  };
  const curseurVisible = () => {
    const saisie = document.querySelector('.handsontableInputHolder');
    return Boolean(saisie && !saisie.classList.contains('ht_editor_hidden'));
  };
  const baremeDe = (th) => {
    const trouves = [...(th.innerText || '').matchAll(/(?:^|[^\d])\/\s*(\d+(?:[.,]\d+)?)/g)];
    return trouves.length ? Number(trouves[trouves.length - 1][1].replace(',', '.')) : null;
  };
  // Le crayon n'est entouré que si un seul devoir correspond : sinon, la consigne reste sans anneau.
  const crayon = () => {
    const grille = grilleNotes();
    if (!grille) return null;
    const parColonne = new Map();
    for (const th of grille.querySelectorAll('thead th[aria-colindex]')) {
      if ((th.innerText || '').trim()) parColonne.set(th.getAttribute('aria-colindex'), th);
    }
    // Des colonnes pas encore chargées pourraient cacher un autre devoir au même barème.
    const annoncees = Number(grille.getAttribute('aria-colcount'));
    const chargees = new Set([...grille.querySelectorAll('thead th[aria-colindex]')].map((th) => th.getAttribute('aria-colindex')));
    if (annoncees > chargees.size) return null;
    let candidats = [...parColonne.entries()].filter(([, th]) =>
      carnet ? baremeDe(th) === baremeCarnet : baremeDe(th) !== null
    );
    if (carnet && candidats.length > 1 && /^\d{4}-\d{2}-\d{2}/.test(carnet.date || '')) {
      const [annee, mois, jour] = carnet.date.slice(0, 10).split('-');
      const date = `${jour}/${mois}/${annee.slice(2)}`;
      candidats = candidats.filter(([, th]) => th.innerText.includes(date));
    }
    if (candidats.length !== 1) return null;
    const selecteur = `td[aria-colindex="${CSS.escape(candidats[0][0])}"] button[data-action][data-row]`;
    return [...grille.querySelectorAll(selecteur)].find(visible) || null;
  };
  const boutonEnregistrer = () =>
    [...document.querySelectorAll('button.btn-primary')].find(
      (b) => !grilleNotes()?.contains(b) && /enregistr/i.test(`${b.getAttribute('title') || ''} ${b.getAttribute('aria-label') || ''}`) && visible(b)
    ) || null;

  const montrer = (cible, texte) => {
    consigne.textContent = texte;
    if (!cible) {
      anneau.style.display = 'none';
      bulle.style.display = 'none';
      return;
    }
    const zone = cible.getBoundingClientRect();
    Object.assign(anneau.style, {
      display: 'block',
      top: `${zone.top - 5}px`,
      left: `${zone.left - 5}px`,
      width: `${zone.width + 10}px`,
      height: `${zone.height + 10}px`,
    });
    bulle.textContent = texte;
    bulle.style.display = 'block';
    const enBas = zone.bottom + 50 < window.innerHeight;
    bulle.style.top = `${enBas ? zone.bottom + 10 : Math.max(4, zone.top - 42)}px`;
    bulle.style.left = `${Math.max(4, Math.min(zone.left, window.innerWidth - 230))}px`;
  };

  const majGuide = () => {
    const ouverte = colonneOuverte();
    if (guide.etape === 1) {
      if (ouverte) guide.etape = 2;
      else {
        guide.boutonEnregistrer = null;
        montrer(crayon(), carnet ? 'Clique sur le crayon du devoir' : 'Clique sur le crayon du devoir à vider');
        return;
      }
    }
    if (guide.etape === 2) {
      if (ouverte && estSelectionnee(premierIndex, ouverte) && !curseurVisible()) guide.etape = 3;
      else {
        montrer(caseEleve(premierIndex, ouverte), curseurVisible() ? 'Échap, puis clique une fois ici' : 'Clique une fois ici');
        return;
      }
    }
    if (guide.etape === 3) {
      if (guide.colle) guide.etape = codes.length ? 4 : 5;
      else if (ouverte && !estSelectionnee(premierIndex, ouverte)) {
        guide.etape = 2;
        return majGuide();
      } else {
        const colonne = lireColonne();
        const erreur = carnet && colonne && colonne.bareme !== null && colonne.bareme !== baremeCarnet;
        const geste = carnet ? 'Ctrl+V, puis vérifie' : 'Ctrl+V : toute la colonne se vide';
        montrer(caseEleve(premierIndex, ouverte), erreur ? 'Mauvaise colonne : ne colle pas' : geste);
        return;
      }
    }
    if (guide.etape === 4) {
      if (guide.code >= codes.length) guide.etape = 5;
      else {
        const code = codes[guide.code];
        montrer(caseEleve(code.index, ouverte), `Clique ici, puis tape ${code.touche}`);
        return;
      }
    }
    if (guide.etape === 5) {
      guide.boutonEnregistrer = boutonEnregistrer();
      if (guide.boutonEnregistrer) guide.attenteEnregistrer = 0;
      else {
        guide.attenteEnregistrer = guide.attenteEnregistrer || Date.now();
        if (Date.now() - guide.attenteEnregistrer > 3000) signaler('enregistrer');
      }
      montrer(guide.boutonEnregistrer, carnet ? 'Vérifie, puis enregistre' : 'Vérifie : enregistre, ou recharge pour annuler');
      return;
    }
    guide.boutonEnregistrer = null;
    montrer(null, 'Guide terminé');
  };
  const codeFait = () => {
    lignesCodes[guide.code].style.opacity = '.45';
    guide.code += 1;
  };
  const suivreClavier = (e) => {
    if (guide.etape !== 4 || guide.code >= codes.length) return;
    const code = codes[guide.code];
    if (e.key.toUpperCase() === code.touche && estSelectionnee(code.index, colonneOuverte())) codeFait();
  };
  // Le collage est seulement constaté : son contenu n'est jamais lu.
  const suivreCollage = () => {
    if (guide.etape === 3) guide.colle = true;
  };
  const suivreClic = (e) => {
    if (guide.etape === 5 && guide.boutonEnregistrer?.contains(e.target)) guide.etape = 6;
    if (e.target === hote || !e.target.closest) return;
    // Un geste doit produire son effet : sinon, la page ne fonctionne plus comme prévu.
    const bouton = e.target.closest('[role="treegrid"].handsontable button[data-action][data-row]');
    if (bouton && guide.etape === 1 && !bouton.classList.contains('disabled') && bouton.getAttribute('data-disabled') !== 'true') {
      setTimeout(() => {
        if (hote.isConnected && !colonneOuverte()) signaler('crayon');
      }, 1500);
    }
    if (e.target.closest('[role="treegrid"].handsontable td.writable')) {
      setTimeout(() => {
        if (hote.isConnected && colonneOuverte() && !grilleNotes().querySelector('td.current')) signaler('case');
      }, 800);
    }
  };
  document.addEventListener('keydown', suivreClavier, true);
  document.addEventListener('paste', suivreCollage, true);
  document.addEventListener('mousedown', suivreClic, true);

  const mettreAJour = () => {
    majControle();
    majGuide();
  };
  const minuterie = setInterval(() => {
    if (hote.isConnected) {
      mettreAJour();
      return;
    }
    clearInterval(minuterie);
    document.removeEventListener('mousedown', noterClic, true);
    document.removeEventListener('keydown', oublierClic, true);
    document.removeEventListener('keydown', suivreClavier, true);
    document.removeEventListener('paste', suivreCollage, true);
    document.removeEventListener('mousedown', suivreClic, true);
  }, 200);

  const lignesCodes = [];
  const liste = document.createElement('ul');
  liste.hidden = !codes.length;
  Object.assign(liste.style, {
    flex: '1',
    minHeight: '0',
    overflowY: 'auto',
    margin: '0',
    padding: '10px 12px 4px',
    listStyle: 'none',
  });
  for (const code of codes) {
    const ligne = document.createElement('li');
    Object.assign(ligne.style, {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '8px',
      marginBottom: '6px',
    });
    const pastille = document.createElement('span');
    pastille.textContent = code.touche;
    Object.assign(pastille.style, {
      flex: '0 0 20px',
      height: '20px',
      lineHeight: '20px',
      textAlign: 'center',
      fontSize: '12px',
      fontWeight: '600',
      color: '#ffffff',
      background: '#a0283c',
      borderRadius: '4px',
    });
    const nom = document.createElement('span');
    nom.textContent = code.nom;
    ligne.append(pastille, nom);
    liste.append(ligne);
    lignesCodes.push(ligne);
  }

  let aDroite = true;
  const cote = document.createElement('button');
  cote.type = 'button';
  cote.textContent = 'Changer de côté';
  cote.addEventListener('click', () => {
    aDroite = !aDroite;
    placer(aDroite);
  });
  const fermer = document.createElement('button');
  fermer.type = 'button';
  fermer.textContent = 'Fermer';
  fermer.addEventListener('click', () => hote.remove());
  // Secours si la page change : passer l'étape à la main.
  const suivant = document.createElement('button');
  suivant.type = 'button';
  suivant.textContent = 'Suivant';
  suivant.addEventListener('click', () => {
    if (guide.etape === 4 && guide.code < codes.length) codeFait();
    else if (guide.etape === 3) guide.colle = true;
    else if (guide.etape < 6) guide.etape = guide.etape === 3 && !codes.length ? 5 : guide.etape + 1;
    mettreAJour();
  });
  const actions = document.createElement('div');
  Object.assign(actions.style, {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '8px',
    padding: '6px 12px 10px',
  });
  for (const b of [suivant, cote, fermer]) {
    Object.assign(b.style, {
      padding: '2px 4px',
      font: "12px 'Segoe UI', system-ui, sans-serif",
      color: couleurs.accent,
      background: 'transparent',
      border: '0',
      borderRadius: '4px',
      cursor: 'pointer',
    });
    b.addEventListener('mouseenter', () => {
      b.style.textDecoration = 'underline';
    });
    b.addEventListener('mouseleave', () => {
      b.style.textDecoration = 'none';
    });
    actions.append(b);
  }

  boite.append(titre, controle, consigne, alerte, liste, actions);
  racine.append(boite);
  document.documentElement.append(hote);
  mettreAJour();
}

function afficherBlocage(r, lecture) {
  zone.replaceChildren();
  ajouterAlerteMiseAJour(lecture);
  ajouter(zone, 'p', 'Ne colle rien', 'verdict bloque');
  const liste = ajouter(zone, 'ul');
  r.blocages.forEach((b) => ajouter(liste, 'li', b));

  const texte = texteTechnique(lecture.technique);
  const details = ajouter(zone, 'details');
  ajouter(details, 'summary', 'Détail technique (sans nom)');
  ajouter(details, 'pre', texte);
  const copier = ajouter(details, 'button', 'Copier ce détail');
  copier.type = 'button';
  copier.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(texte);
      copier.textContent = 'Copié';
    } catch {
      copier.textContent = 'Copie impossible : sélectionne le texte à la main';
    }
  });
}

const attendre = (ms) => new Promise((fin) => setTimeout(fin, ms));

// La fenêtre n'a pas toujours la main quand elle vient de s'ouvrir : on réessaie, puis on passe par une zone de texte.
async function lirePressePapiers() {
  for (let essai = 0; essai < 5; essai += 1) {
    window.focus();
    try {
      return await navigator.clipboard.readText();
    } catch {
      await attendre(120);
    }
  }
  const champ = document.createElement('textarea');
  document.body.append(champ);
  champ.focus();
  const reussi = document.execCommand('paste');
  const texte = champ.value;
  champ.remove();
  if (!reussi) throw new Error('Presse-papiers refusé');
  return texte;
}

async function ecrirePressePapiers(texte) {
  for (let essai = 0; essai < 5; essai += 1) {
    window.focus();
    try {
      await navigator.clipboard.writeText(texte);
      return;
    } catch {
      await attendre(120);
    }
  }
  const champ = document.createElement('textarea');
  champ.value = texte;
  document.body.append(champ);
  champ.select();
  const reussi = document.execCommand('copy');
  champ.remove();
  if (!reussi) throw new Error('Presse-papiers refusé');
}

async function ongletEcoleDirecte() {
  const [onglet] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (onglet && estEcoleDirecte(onglet.url)) return onglet;
  afficherMessage('Ouvre un devoir, les appréciations ou la messagerie sur École Directe', 'bloque');
  return null;
}

async function lireGrille(onglet) {
  const retours = await chrome.scripting.executeScript({
    target: { tabId: onglet.id, allFrames: true },
    files: ['analyseur.js'],
  });
  const lectures = retours.map((x) => x.result).filter(Boolean);
  if (!lectures.length) {
    afficherMessage('Lecture impossible sur cette page.', 'bloque');
    return null;
  }
  lectures.sort((a, b) => b.lignes.length - a.lignes.length);
  return lectures[0];
}

// Ne touche pas à la grille : prépare un collage de lignes vides, que l'enseignant colle lui-même.
async function preparerEffacement() {
  bouton.hidden = true;
  boutonVider.hidden = true;
  afficherMessage('Lecture…', 'attention');
  try {
    const onglet = await ongletEcoleDirecte();
    if (!onglet) return;
    const lecture = await lireGrille(onglet);
    if (!lecture) return;
    const resultat = lignesAVider(lecture);
    if (!resultat.ok) {
      afficherBlocage(resultat, lecture);
      return;
    }
    await ecrirePressePapiers('\n'.repeat(Math.max(1, resultat.nombre - 1)));
    afficherEffacement(resultat, lecture);
    // Si le panneau échoue, les étapes restent lisibles dans cette fenêtre.
    await chrome.scripting
      .executeScript({
        target: { tabId: onglet.id },
        func: panneauCodes,
        args: [[], null, resultat.premierIndex, lecture.technique?.reperes || []],
      })
      .catch(() => {});
  } catch {
    afficherMessage('Préparation impossible sur cette page.', 'bloque');
  } finally {
    bouton.hidden = false;
    boutonVider.hidden = false;
  }
}

// Page des appréciations : le panneau, posé sur la page, suit le curseur d'un élève à l'autre.
async function preparerAppreciations(onglet, carnet) {
  const retours = await chrome.scripting.executeScript({
    target: { tabId: onglet.id, allFrames: true },
    files: ['analyseurappr.js'],
  });
  const lecture = retours.map((x) => x.result).filter(Boolean).find((l) => l.table) || { table: false, lignes: [], reperes: [] };
  const resultat = rapprocherAppreciations(lecture, carnet);
  if (!resultat.ok) {
    zone.replaceChildren();
    ajouter(zone, 'p', 'Ne colle rien', 'verdict bloque');
    const liste = ajouter(zone, 'ul');
    resultat.blocages.forEach((b) => ajouter(liste, 'li', b));
    return;
  }
  const autre = lecture.periodes.find((p) => p !== carnet.periode);
  zone.replaceChildren();
  if (lecture.reperes.length) {
    ajouter(zone, 'p', `Mettre à jour l'extension : École Directe a changé (${lecture.reperes.join(', ')})`, 'verdict bloque');
  }
  ajouter(zone, 'p', `${carnet.classe} : ${resultat.nombre} élèves sur ${resultat.nombre}`, 'verdict ok');
  ajouter(zone, 'p', `Appréciations ${carnet.periode}`, 'compte');
  if (autre) ajouter(zone, 'p', `La page est sur ${autre} : choisis ${carnet.periode} avant de coller`, 'verdict bloque');
  const etapes = ajouter(zone, 'ol');
  ajouter(etapes, 'li', 'Clique dans la zone du premier élève');
  ajouter(etapes, 'li', 'Ctrl+V, relis, puis Entrée');
  ajouter(etapes, 'li', 'Enregistrer');
  if (resultat.tropLongs) {
    ajouter(zone, 'p', `${resultat.tropLongs} texte(s) de plus de ${lecture.limite} caractères seront refusés : raccourcis-les dans le Carnet, puis reclique sur « Reporter »`, 'verdict bloque');
  }
  if (resultat.sansTexte) ajouter(zone, 'p', `${resultat.sansTexte} sans appréciation dans le carnet`, 'verdict attention');
  if (lecture.remplies) ajouter(zone, 'p', `${lecture.remplies} case(s) déjà remplie(s) : elles ne seront pas touchées`, 'verdict attention');

  // Les noms quittent le presse-papiers : seul le texte de l'élève en cours y sera placé.
  await ecrirePressePapiers(' ').catch(() => {});
  await chrome.scripting.executeScript({
    target: { tabId: onglet.id },
    func: panneauAppreciations,
    args: [resultat.eleves, carnet.periode, lecture.reperes],
  });
}

async function preparer() {
  bouton.hidden = true;
  boutonVider.hidden = true;
  boutonMessages.hidden = true;
  afficherMessage('Lecture…', 'attention');
  try {
    const onglet = await ongletEcoleDirecte();
    if (!onglet) return;

    let contenu = '';
    try {
      contenu = await lirePressePapiers();
    } catch {
      afficherMessage('Presse-papiers refusé : clique sur Recommencer', 'bloque');
      return;
    }
    const carnet = lireExportCarnet(contenu);
    if (!carnet) {
      // Sur la messagerie, pas d'export à attendre : la fenêtre propose les modèles de messages.
      const objet = await lireObjet(onglet);
      if (objet?.messagerie || objet?.champ) {
        afficherMessages(objet);
        return;
      }
      afficherMessage('Clique d’abord sur « Reporter… » dans le Carnet, pour tes notes ou tes appréciations', 'bloque');
      return;
    }
    if (carnet.format === FORMAT_APPRECIATIONS) {
      await preparerAppreciations(onglet, carnet);
      return;
    }

    const lecture = await lireGrille(onglet);
    if (!lecture) return;

    const resultat = rapprocher(lecture, carnet);
    if (!resultat.ok) {
      afficherBlocage(resultat, lecture);
      return;
    }

    // Les noms quittent le presse-papiers : il ne reste que la colonne de notes à coller.
    await ecrirePressePapiers(resultat.colonne);
    afficherPret(resultat, carnet, lecture);
    // Si le panneau échoue, la liste reste lisible dans cette fenêtre.
    await chrome.scripting
      .executeScript({
        target: { tabId: onglet.id },
        func: panneauCodes,
        args: [
          resultat.aCompleter,
          { evaluation: carnet.evaluation, max: carnet.max, date: carnet.date },
          resultat.premierIndex,
          lecture.technique?.reperes || [],
        ],
      })
      .catch(() => {});
  } catch {
    afficherMessage('Préparation impossible sur cette page.', 'bloque');
  } finally {
    bouton.hidden = false;
    boutonVider.hidden = false;
    boutonMessages.hidden = false;
  }
}

// Modèles de messages : partout, même hors d'École Directe (mot à écrire dans le carnet de correspondance).
async function ouvrirMessages() {
  const [onglet] = await chrome.tabs.query({ active: true, currentWindow: true });
  afficherMessages(onglet && estEcoleDirecte(onglet.url) ? await lireObjet(onglet) : null);
}

// Le clic sur l'icône de l'extension lance la préparation ; rien ne tourne sans ce clic.
bouton.addEventListener('click', preparer);
boutonVider.addEventListener('click', preparerEffacement);
boutonMessages.addEventListener('click', () => ouvrirMessages().catch(() => afficherMessages(null)));
preparer();
