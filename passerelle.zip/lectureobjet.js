// Lecture seule, sur la messagerie d'École Directe : lit uniquement l'objet que l'enseignant a tapé.
// Ne lit ni les destinataires ni les messages ; n'écrit rien, ne clique sur rien, n'envoie rien.
(() => {
  'use strict';

  const visible = (el) => {
    const zone = el.getBoundingClientRect();
    return zone.width > 0 && zone.height > 0;
  };
  const OBJET = /\b(objet|sujet|subject)\b/i;
  const decrit = (el) =>
    [
      el.id,
      el.name,
      el.placeholder,
      el.title,
      el.getAttribute('aria-label'),
      el.getAttribute('formcontrolname'),
      ...[...(el.labels || [])].map((l) => l.innerText),
    ].join(' ');
  // Libellé « Objet » posé à côté du champ, sans lien `for` : on remonte de quelques niveaux.
  const libelleVoisin = (el) => {
    let parent = el.parentElement;
    for (let i = 0; i < 3 && parent; i += 1, parent = parent.parentElement) {
      if (parent.querySelectorAll('input, textarea').length > 1) return false;
      if (/^\s*(objet|sujet)\b/i.test(parent.innerText || '')) return true;
    }
    return false;
  };

  const champs = [...document.querySelectorAll('input:not([type]), input[type="text"], input[type="search"]')].filter(visible);
  const champ = champs.find((c) => OBJET.test(decrit(c))) || champs.find(libelleVoisin);
  const messagerie = /messag/i.test(location.pathname + location.hash);
  if (!champ) return messagerie ? { champ: false, objet: '', messagerie } : null;
  return { champ: true, objet: champ.value.trim().slice(0, 200), messagerie };
})();
