'use strict';

// Bibliothèque des modèles de messages : rien n'est lu sur la page ni envoyé.
// Les crochets [ ] sont des cases que l'enseignant complète dans la fenêtre.
// `mots` : morceaux de mots cherchés dans l'objet (sans accents ni majuscules).
const THEMES_MESSAGES = [
  {
    id: 'tenue',
    nom: 'Oubli de tenue',
    mots: ['tenue', 'oubli', 'affaires', 'basket', 'chaussure', 'survet', 'jogging', 'short'],
    modeles: [
      {
        id: 'tenue-1',
        titre: '1er oubli',
        objet: 'Oubli de tenue en EPS',
        mail:
          'Madame, Monsieur,\n\nJe vous informe que [prénom] n’avait pas sa tenue de sport lors du cours d’EPS du [date]. ' +
          'Une tenue adaptée (chaussures de sport, survêtement ou short, tee-shirt de rechange) est indispensable pour pratiquer en sécurité.\n\n' +
          'Je vous remercie de veiller à ce qu’elle soit dans son sac pour les prochains cours.\n\nCordialement,',
        mot: 'Madame, Monsieur,\n[prénom] n’avait pas sa tenue d’EPS le [date]. Merci d’y veiller pour les prochains cours.',
      },
      {
        id: 'tenue-2',
        titre: 'Oublis répétés',
        objet: 'Oublis répétés de la tenue d’EPS',
        mots: ['rappel', 'encore', 'nouveau', 'nouvel', 'relance', 'repet', 'plusieurs', 'recidive', '2e', '3e'],
        mail:
          'Madame, Monsieur,\n\nMalgré un premier message, [prénom] n’avait de nouveau pas sa tenue de sport le [date]. ' +
          'C’est le [nombre]e oubli depuis le début de l’année. Sans tenue, votre enfant ne peut pas pratiquer et son évaluation en pâtit.\n\n' +
          'Je compte sur vous pour l’aider à préparer son sac la veille des cours d’EPS.\n\nCordialement,',
        mot: 'Madame, Monsieur,\nNouvel oubli de la tenue d’EPS le [date] ([nombre]e oubli). Merci de vérifier le sac de [prénom] la veille des cours.',
      },
      {
        id: 'tenue-3',
        titre: 'Demande de rendez-vous',
        objet: 'Tenue d’EPS : demande de rendez-vous',
        mots: ['rendez', 'rdv', 'convoc', 'rencontr'],
        mail:
          'Madame, Monsieur,\n\nLes oublis de tenue de [prénom] se répètent ([nombre] depuis le début de l’année) malgré mes précédents messages. ' +
          'Je souhaiterais vous rencontrer pour en parler et trouver ensemble une solution.\n\n' +
          'Je vous propose le [date du rendez-vous]. Si ce créneau ne vous convient pas, n’hésitez pas à m’en proposer un autre.\n\nCordialement,',
        mot: 'Madame, Monsieur,\nLes oublis de tenue se répètent ([nombre]). Je souhaite vous rencontrer : je vous propose le [date du rendez-vous].',
      },
    ],
  },
  {
    id: 'dispense',
    nom: 'Dispense, inaptitude',
    mots: ['dispens', 'inapt', 'certificat', 'medical', 'medecin', 'exempt'],
    modeles: [
      {
        id: 'dispense-1',
        titre: 'Certificat manquant',
        objet: 'Dispense d’EPS : certificat médical',
        mots: ['certificat', 'justif', 'manqu'],
        mail:
          'Madame, Monsieur,\n\n[prénom] m’a indiqué ne pas pouvoir pratiquer l’EPS depuis le [date]. ' +
          'Pour une inaptitude de plus d’un cours, un certificat médical est nécessaire : merci de le transmettre à la vie scolaire ou de me le faire parvenir.\n\n' +
          'Cordialement,',
        mot: 'Madame, Monsieur,\nMerci de fournir un certificat médical pour l’inaptitude de [prénom] en EPS depuis le [date].',
      },
      {
        id: 'dispense-2',
        titre: 'Présence en cours',
        objet: 'Inaptitude en EPS : présence au cours',
        mots: ['presence', 'present', 'assister', 'perman'],
        mail:
          'Madame, Monsieur,\n\nJe vous rappelle qu’une inaptitude à la pratique ne dispense pas de la présence en cours d’EPS. ' +
          '[prénom] reste en cours et peut tenir d’autres rôles : arbitre, observateur, chronométreur, aide à l’organisation.\n\n' +
          'Seule une décision de l’établissement peut autoriser une absence du cours.\n\nCordialement,',
        mot: 'Madame, Monsieur,\nUne inaptitude ne dispense pas de la présence en EPS : [prénom] assiste au cours et tient d’autres rôles.',
      },
      {
        id: 'dispense-3',
        titre: 'Inaptitude partielle',
        objet: 'Inaptitude partielle en EPS',
        mots: ['partiel', 'adapt', 'amenag'],
        mail:
          'Madame, Monsieur,\n\nJ’ai bien reçu le certificat d’inaptitude partielle de [prénom] jusqu’au [date de fin]. ' +
          'Pendant cette période, la pratique sera adaptée : [adaptations].\n\n' +
          'L’évaluation tiendra compte de ces aménagements.\n\nCordialement,',
        mot: 'Madame, Monsieur,\nCertificat d’inaptitude partielle bien reçu (jusqu’au [date de fin]). Pratique adaptée : [adaptations].',
      },
    ],
  },
  {
    id: 'absence',
    nom: 'Absences en EPS',
    mots: ['absen', 'retard', 'manque'],
    modeles: [
      {
        id: 'absence-1',
        titre: 'Absences répétées',
        objet: 'Absences répétées en EPS',
        mail:
          'Madame, Monsieur,\n\n[prénom] a été absent(e) à [nombre] cours d’EPS depuis le [date]. ' +
          'Ces absences l’empêchent de progresser et risquent de compromettre son évaluation.\n\n' +
          'Pourriez-vous m’en indiquer la raison ? Je reste disponible pour en parler.\n\nCordialement,',
        mot: 'Madame, Monsieur,\n[prénom] a manqué [nombre] cours d’EPS depuis le [date]. Merci de m’en indiquer la raison.',
      },
      {
        id: 'absence-2',
        titre: 'Évaluation manquée',
        objet: 'Évaluation d’EPS manquée : rattrapage',
        mots: ['eval', 'rattrap', 'epreuve', 'controle'],
        mail:
          'Madame, Monsieur,\n\n[prénom] était absent(e) à l’évaluation de [activité] du [date]. ' +
          'Un rattrapage est prévu le [date du rattrapage], pendant le cours.\n\n' +
          'Si l’absence est due à une raison médicale, merci de fournir un justificatif.\n\nCordialement,',
        mot: 'Madame, Monsieur,\nÉvaluation de [activité] manquée le [date]. Rattrapage prévu le [date du rattrapage].',
      },
    ],
  },
  {
    id: 'blessure',
    nom: 'Blessure en cours',
    mots: ['bless', 'chute', 'tomb', 'entorse', 'douleur', 'accident', 'choc'],
    modeles: [
      {
        id: 'blessure-1',
        titre: 'Information aux parents',
        objet: 'Blessure en cours d’EPS',
        mail:
          'Madame, Monsieur,\n\nJe vous informe que [prénom] s’est blessé(e) pendant le cours d’EPS du [date], lors de l’activité [activité]. ' +
          '[ce qui s’est passé].\n\n' +
          'Votre enfant a été [pris(e) en charge par l’infirmerie / surveillé(e) jusqu’à la fin du cours]. ' +
          'Si la douleur persiste, je vous conseille de consulter un médecin, et de me transmettre un certificat si une inaptitude est nécessaire.\n\nCordialement,',
        mot: 'Madame, Monsieur,\n[prénom] s’est blessé(e) en EPS le [date] ([activité]). Si la douleur persiste, merci de consulter un médecin.',
      },
    ],
  },
  {
    id: 'attitude',
    nom: 'Attitude en cours',
    mots: ['comport', 'attitude', 'refus', 'respect', 'insolen', 'bavard', 'incident', 'sanction', 'exclu', 'travail', 'investiss'],
    modeles: [
      {
        id: 'attitude-1',
        titre: 'Attitude',
        objet: 'Attitude en cours d’EPS',
        mail:
          'Madame, Monsieur,\n\nJe souhaite vous informer de l’attitude de [prénom] en EPS. Lors du cours du [date], [ce qui s’est passé].\n\n' +
          'Ce comportement gêne le bon déroulement du cours. Je compte sur vous pour en parler avec votre enfant, ' +
          'et je reste disponible pour vous rencontrer si vous le souhaitez.\n\nCordialement,',
        mot: 'Madame, Monsieur,\nAttitude inadaptée en EPS le [date] : [ce qui s’est passé]. Merci d’en parler avec [prénom].',
      },
      {
        id: 'attitude-2',
        titre: 'Refus de pratiquer',
        objet: 'Refus de pratiquer en EPS',
        mots: ['refus', 'pratiqu', 'particip'],
        mail:
          'Madame, Monsieur,\n\nLors du cours d’EPS du [date], [prénom] a refusé de pratiquer l’activité [activité], sans justificatif. ' +
          'La participation fait partie des attendus du cours et compte dans l’évaluation.\n\n' +
          'Si une raison particulière explique ce refus, n’hésitez pas à m’en faire part.\n\nCordialement,',
        mot: 'Madame, Monsieur,\n[prénom] a refusé de pratiquer en EPS le [date] ([activité]), sans justificatif.',
      },
    ],
  },
  {
    id: 'felicitations',
    nom: 'Félicitations',
    mots: ['felicit', 'bravo', 'progres', 'encourag', 'implic', 'investi', 'reussi', 'positif'],
    modeles: [
      {
        id: 'felicitations-1',
        titre: 'Progrès',
        objet: 'Félicitations en EPS',
        mail:
          'Madame, Monsieur,\n\nJe tenais à vous faire part des progrès de [prénom] en EPS, en particulier en [activité]. ' +
          '[ce qui a progressé].\n\nBravo à votre enfant : qu’il ou elle continue ainsi !\n\nCordialement,',
        mot: 'Madame, Monsieur,\nBeaux progrès de [prénom] en [activité]. Bravo, qu’il ou elle continue ainsi !',
      },
      {
        id: 'felicitations-2',
        titre: 'Implication',
        objet: 'Implication en EPS',
        mots: ['implic', 'investi', 'role', 'arbitr', 'coach', 'aide'],
        mail:
          'Madame, Monsieur,\n\nJe souhaite souligner l’implication de [prénom] en EPS : [exemple, comme son rôle d’arbitre ou d’aide auprès de ses camarades].\n\n' +
          'Cette attitude est un vrai atout pour le groupe. Bravo !\n\nCordialement,',
        mot: 'Madame, Monsieur,\nBelle implication de [prénom] en EPS : [exemple]. Bravo !',
      },
    ],
  },
  {
    id: 'natation',
    nom: 'Natation',
    mots: ['natation', 'piscine', 'nage', 'bonnet', 'maillot', 'lunette'],
    modeles: [
      {
        id: 'natation-1',
        titre: 'Matériel',
        objet: 'Natation : matériel',
        mots: ['bonnet', 'maillot', 'materiel', 'oubli', 'lunette'],
        mail:
          'Madame, Monsieur,\n\n[prénom] n’avait pas son matériel de natation le [date]. ' +
          'Pour chaque séance, il faut un maillot de bain (pas de short de bain), un bonnet, une serviette et, si possible, des lunettes.\n\n' +
          'Merci d’y veiller pour les prochaines séances.\n\nCordialement,',
        mot: 'Madame, Monsieur,\nMatériel de natation oublié le [date]. Il faut : maillot, bonnet, serviette (lunettes conseillées).',
      },
      {
        id: 'natation-2',
        titre: 'Début du cycle',
        objet: 'Début du cycle de natation',
        mots: ['debut', 'cycle', 'seance', 'calendrier'],
        mail:
          'Madame, Monsieur,\n\nLe cycle de natation commence le [date] et se déroulera à [lieu], [jour et horaires].\n\n' +
          'Matériel à prévoir à chaque séance : maillot de bain (pas de short de bain), bonnet, serviette et, si possible, des lunettes. ' +
          'En cas de contre-indication médicale, merci de me transmettre un certificat.\n\nCordialement,',
        mot: 'Madame, Monsieur,\nNatation à partir du [date] à [lieu], [jour et horaires]. Prévoir maillot, bonnet, serviette.',
      },
    ],
  },
  {
    id: 'sortie',
    nom: 'Sortie, déplacement',
    mots: ['sortie', 'deplacement', 'autoris', 'bus', 'voyage', 'transport', ' car '],
    modeles: [
      {
        id: 'sortie-1',
        titre: 'Autorisation',
        objet: 'Sortie EPS : autorisation',
        mots: ['autoris', 'coupon', 'signer', 'signature'],
        mail:
          'Madame, Monsieur,\n\nDans le cadre du cours d’EPS, la classe se rendra à [lieu] le [date], de [heure de départ] à [heure de retour], pour [activité].\n\n' +
          'Merci de remplir et signer l’autorisation, à rendre au plus tard le [date limite].\n\nCordialement,',
        mot: 'Madame, Monsieur,\nSortie EPS à [lieu] le [date] ([heure de départ] – [heure de retour]). Autorisation à rendre avant le [date limite].',
      },
      {
        id: 'sortie-2',
        titre: 'Informations pratiques',
        objet: 'Sortie EPS : informations pratiques',
        mots: ['info', 'pratique', 'horaire', 'prevoir'],
        mail:
          'Madame, Monsieur,\n\nVoici les informations pour la sortie à [lieu] du [date] :\n' +
          '– départ : [heure de départ], [lieu de départ] ;\n– retour prévu : [heure de retour] ;\n– à prévoir : [à prévoir].\n\nCordialement,',
        mot: 'Madame, Monsieur,\nSortie du [date] : départ [heure de départ], retour [heure de retour]. À prévoir : [à prévoir].',
      },
    ],
  },
  {
    id: 'as',
    nom: 'Association sportive',
    mots: ['association sportive', 'unss', ' as ', 'competition', 'entrainement', 'licence'],
    modeles: [
      {
        id: 'as-1',
        titre: 'Inscription',
        objet: 'Association sportive : inscription',
        mots: ['inscri', 'licence', 'adhes'],
        mail:
          'Madame, Monsieur,\n\nL’association sportive du collège propose [activités] le [jour et horaires]. ' +
          'L’inscription coûte [montant] pour l’année et comprend la licence UNSS.\n\n' +
          'Si votre enfant souhaite participer, merci de rendre le dossier d’inscription avant le [date limite].\n\nCordialement,',
        mot: 'Madame, Monsieur,\nAS : [activités] le [jour et horaires]. Inscription : [montant], dossier à rendre avant le [date limite].',
      },
      {
        id: 'as-2',
        titre: 'Compétition',
        objet: 'Association sportive : compétition',
        mots: ['competition', 'championnat', 'tournoi', 'rencontre'],
        mail:
          'Madame, Monsieur,\n\n[prénom] est sélectionné(e) pour la compétition de [activité] du [date] à [lieu]. ' +
          'Départ : [heure de départ] ; retour prévu : [heure de retour].\n\n' +
          'Merci de confirmer sa participation avant le [date limite].\n\nCordialement,',
        mot: 'Madame, Monsieur,\n[prénom] participe à la compétition de [activité] le [date] à [lieu] ([heure de départ] – [heure de retour]).',
      },
    ],
  },
  {
    id: 'evaluation',
    nom: 'Évaluation',
    mots: ['eval', 'epreuve', 'controle', 'note', 'bilan', 'resultat', 'examen', 'brevet'],
    modeles: [
      {
        id: 'evaluation-1',
        titre: 'Épreuve à venir',
        objet: 'Évaluation d’EPS à venir',
        mots: ['venir', 'prochain', 'prevu', 'date'],
        mail:
          'Madame, Monsieur,\n\nL’évaluation de fin de cycle de [activité] aura lieu le [date]. ' +
          'Elle porte sur [ce qui est évalué].\n\nMerci de veiller à ce que votre enfant soit présent(e) et ait sa tenue.\n\nCordialement,',
        mot: 'Madame, Monsieur,\nÉvaluation de [activité] le [date]. Présence et tenue indispensables.',
      },
      {
        id: 'evaluation-2',
        titre: 'Résultat',
        objet: 'Résultat de l’évaluation d’EPS',
        mots: ['resultat', 'note', 'bilan'],
        mail:
          'Madame, Monsieur,\n\n[prénom] a obtenu [note] à l’évaluation de [activité]. [commentaire].\n\n' +
          'Je reste disponible pour toute question.\n\nCordialement,',
        mot: 'Madame, Monsieur,\nÉvaluation de [activité] : [note]. [commentaire].',
      },
    ],
  },
  {
    id: 'parents',
    nom: 'Réponse, rendez-vous',
    mots: ['rendez', 'rdv', 'rencontr', 'entretien', 'reponse', ' re ', 'demande', 'question'],
    modeles: [
      {
        id: 'parents-1',
        titre: 'Accusé de réception',
        objet: 'Re : [objet du message reçu]',
        mots: [' re ', 'reponse', 'recu', 'merci'],
        mail:
          'Madame, Monsieur,\n\nJe vous remercie pour votre message, que j’ai bien reçu. [réponse].\n\n' +
          'Je reste à votre disposition.\n\nCordialement,',
        mot: 'Madame, Monsieur,\nMessage bien reçu, merci. [réponse].',
      },
      {
        id: 'parents-2',
        titre: 'Proposition de rendez-vous',
        objet: 'Proposition de rendez-vous',
        mots: ['rendez', 'rdv', 'rencontr', 'entretien'],
        mail:
          'Madame, Monsieur,\n\nJe souhaiterais vous rencontrer au sujet de [prénom] en EPS. ' +
          'Je vous propose le [date du rendez-vous] au collège.\n\n' +
          'Si ce créneau ne vous convient pas, n’hésitez pas à m’en proposer un autre.\n\nCordialement,',
        mot: 'Madame, Monsieur,\nJe souhaite vous rencontrer au sujet de [prénom] : je vous propose le [date du rendez-vous].',
      },
    ],
  },
  {
    id: 'collegues',
    nom: 'Collègues',
    mots: ['vie scolaire', 'professeur principal', ' pp ', 'cpe', 'infirm', 'collegue', 'signalement'],
    modeles: [
      {
        id: 'collegues-1',
        titre: 'Professeur principal',
        objet: 'EPS : information sur un élève',
        mots: ['professeur principal', ' pp ', 'info'],
        mail:
          'Bonjour,\n\nPour information, en EPS, [prénom] [ce qui se passe]. ' +
          '[Ce qui a déjà été fait : message aux parents, échange avec l’élève…].\n\n' +
          'Je voulais t’en faire part pour avoir une vue d’ensemble. Bonne journée,',
        mot: 'Bonjour,\nPour info, en EPS : [prénom] [ce qui se passe].',
      },
      {
        id: 'collegues-2',
        titre: 'Vie scolaire',
        objet: 'EPS : signalement à la vie scolaire',
        mots: ['vie scolaire', 'cpe', 'signalement', 'absen', 'incident'],
        mail:
          'Bonjour,\n\nJe vous signale que [prénom] [ce qui s’est passé] lors du cours d’EPS du [date], de [heure de début] à [heure de fin].\n\n' +
          'Merci pour le suivi. Bonne journée,',
        mot: 'Bonjour,\nSignalement EPS du [date] : [prénom] [ce qui s’est passé].',
      },
      {
        id: 'collegues-3',
        titre: 'Infirmerie',
        objet: 'EPS : élève à l’infirmerie',
        mots: ['infirm', 'bless', 'malade', 'soin'],
        mail:
          'Bonjour,\n\n[prénom] s’est blessé(e) ou senti(e) mal pendant le cours d’EPS du [date] : [ce qui s’est passé]. ' +
          'Je vous l’ai envoyé(e) à [heure].\n\nPourriez-vous me dire comment cela s’est passé ? Merci,',
        mot: 'Bonjour,\n[prénom] envoyé(e) à l’infirmerie à [heure] après le cours d’EPS : [ce qui s’est passé].',
      },
    ],
  },
];

// « Rappel : oubli de tenue » → « rappel oubli de tenue » : sans accents, sans majuscules, espaces autour.
function normaliserObjet(texte) {
  return ` ${String(texte || '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()} `;
}

function compterMots(texte, mots) {
  return (mots || []).filter((m) => texte.includes(m)).length;
}

// Les modèles les plus proches de l'objet : le thème d'abord, la variante ensuite.
function suggererModeles(objet, maximum = 3) {
  const texte = normaliserObjet(objet);
  if (!texte.trim()) return [];
  const trouves = [];
  THEMES_MESSAGES.forEach((theme, rangTheme) => {
    const scoreTheme = compterMots(texte, theme.mots);
    theme.modeles.forEach((modele, rang) => {
      const scoreModele = compterMots(texte, modele.mots);
      if (!scoreTheme && !scoreModele) return;
      // Le thème pèse plus lourd ; à égalité, la première variante (la plus courante) passe devant.
      trouves.push({ theme, modele, score: scoreTheme * 10 + scoreModele * 3 - rang, rangTheme });
    });
  });
  trouves.sort((a, b) => b.score - a.score || a.rangTheme - b.rangTheme);
  return trouves.slice(0, maximum);
}

function trouverModele(id) {
  for (const theme of THEMES_MESSAGES) {
    const modele = theme.modeles.find((m) => m.id === id);
    if (modele) return { theme, modele };
  }
  return null;
}

// Cases à compléter, dans l'ordre où elles apparaissent, sans doublon.
function casesDuModele(...textes) {
  const vues = [];
  for (const texte of textes) {
    for (const m of String(texte).matchAll(/\[([^\]]+)\]/g)) if (!vues.includes(m[1])) vues.push(m[1]);
  }
  return vues;
}

function remplirModele(texte, valeurs) {
  return String(texte).replace(/\[([^\]]+)\]/g, (tout, nom) => (valeurs[nom] || '').trim() || tout);
}
