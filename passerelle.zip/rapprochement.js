'use strict';

// Rapproche les lignes lues dans la grille des élèves copiés depuis le carnet.
// Tout se fait dans la fenêtre de l'extension, sur l'ordinateur : rien n'est conservé ni envoyé.

const FORMAT_CARNET = 'carnet-eps-ecole-directe';
const FORMAT_APPRECIATIONS = 'carnet-eps-appreciations';
const TOUCHES_CODES = { Abs: 'A', Disp: 'D', NE: 'N' };

const PREFIXE_CARNET = 'CARNET-EPS:';

// Le Carnet copie un texte codé, pour qu'un collage par erreur ne montre ni nom ni note.
function decoderExportCarnet(texte) {
  const binaire = atob(String(texte).trim().slice(PREFIXE_CARNET.length));
  return new TextDecoder().decode(Uint8Array.from(binaire, (c) => c.charCodeAt(0)));
}

function lireExportCarnet(texte) {
  try {
    if (!String(texte).trim().startsWith(PREFIXE_CARNET)) return null;
    const donnees = JSON.parse(decoderExportCarnet(texte));
    if (
      donnees &&
      (donnees.format === FORMAT_CARNET || donnees.format === FORMAT_APPRECIATIONS) &&
      donnees.version === 1 &&
      Array.isArray(donnees.eleves)
    ) {
      return donnees;
    }
  } catch {
    // Le presse-papiers contient autre chose : ce n'est pas une erreur.
  }
  return null;
}

// Mots du nom, sans accents, majuscules, ponctuation, chiffres ni ordre.
// Tout ce qui est entre parenthèses ou crochets (classe, groupe : « (1MAR.) ») est ignoré.
// Un mot coupé par la page (« Etien… », « Etien... ») ou une initiale (« J. ») finit par « * » :
// il ne sert que de début de mot.
function motsDuNom(texte) {
  return String(texte || '')
    .replace(/\([^()]*\)|\[[^\]]*\]/g, ' ')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    // « N'Diaye » et « Ndiaye » : l'apostrophe colle les deux morceaux.
    .replace(/(\p{L})['’`](?=\p{L})/gu, '$1')
    .replace(/(\p{L})\s*(?:…|\.{2,})/gu, '$1* ')
    .replace(/\b(\p{L})\.(?=\s|$)/gu, '$1* ')
    .replace(/[^\p{L}*]+/gu, ' ')
    .split(/\s+/)
    .map((mot) => mot.replace(/\*+/g, '*'))
    .filter((mot) => mot && mot !== '*')
    .sort();
}

const motCorrespond = (motPage, motCarnet) =>
  motPage.endsWith('*') ? motCarnet.startsWith(motPage.slice(0, -1)) : motPage === motCarnet;

// Chaque mot de `petits` trouve un mot différent dans `grands` (essai de toutes les attributions,
// les noms ont peu de mots).
function contientTout(grands, petits) {
  const pris = new Array(grands.length).fill(false);
  const placer = (i) => {
    if (i === petits.length) return true;
    for (let j = 0; j < grands.length; j += 1) {
      if (!pris[j] && motCorrespond(petits[i], grands[j])) {
        pris[j] = true;
        if (placer(i + 1)) return true;
        pris[j] = false;
      }
    }
    return false;
  };
  return placer(0);
}

const clesIdentiques = (motsPage, motsCarnet) => motsPage.length === motsCarnet.length && contientTout(motsCarnet, motsPage);
const sansCoupure = (mots) => mots.map((m) => m.replace(/\*$/, ''));

// Du plus sûr au moins sûr ; on s'arrête au premier niveau qui désigne un seul élève.
// 1. mêmes mots ; 2. nom de la page raccourci (mots coupés, prénom en moins) ;
// 3. la page a des mots en plus (2e prénom) ; jamais deux élèves possibles.
function candidatsPourNom(mots, eleves) {
  if (!mots.length) return [];
  const niveaux = [
    (el) => clesIdentiques(mots, el.mots),
    (el) => contientTout(el.mots, mots),
    (el) => el.mots.length >= 2 && contientTout(sansCoupure(mots), el.mots),
  ];
  for (const critere of niveaux) {
    const trouves = eleves.filter(critere);
    if (trouves.length) return trouves;
  }
  return [];
}

// Lignes de la grille qui ne sont pas des élèves.
function ligneTechnique(nom) {
  const texte = String(nom || '')
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .trim();
  const effectif = texte.match(/^(\d+)\s+eleves?$/);
  if (effectif) return { sorte: 'effectif', nombre: Number(effectif[1]) };
  if (/^(moyenne|moy\.?)\b/.test(texte)) return { sorte: 'moyenne' };
  return null;
}

// Pour vider la colonne : les lignes d'élèves de la grille, sans avoir besoin du carnet.
function lignesAVider(lecture) {
  const t = lecture.technique;
  const blocages = [];
  if (t.grilles !== 1) blocages.push('Grille introuvable : ouvre un devoir. Si tu y es déjà, mets à jour l’extension.');
  if (!t.fin) blocages.push("Le bas de la grille n'a pas été atteint.");
  if (t.debutManquant) blocages.push('Le début de la liste semble manquer.');
  if (t.trous) blocages.push('Des lignes de la grille n’ont pas été lues.');
  if (t.conflits) blocages.push('La lecture de la grille est incohérente : recommence.');

  let effectif = null;
  const eleves = [];
  for (const ligne of lecture.lignes) {
    const technique = ligneTechnique(ligne.nom);
    if (technique?.sorte === 'effectif') effectif = technique.nombre;
    else if (!technique && ligne.nom) eleves.push(ligne);
  }
  if (!eleves.length) blocages.push('Aucun élève trouvé dans la grille.');
  if (effectif !== null && effectif !== eleves.length) {
    blocages.push(`École Directe annonce ${effectif} élèves, ${eleves.length} ont été lus.`);
  }
  if (eleves.some((l, i) => i > 0 && l.index !== eleves[i - 1].index + 1)) {
    blocages.push('La liste des élèves est coupée par une autre ligne.');
  }
  if (blocages.length) return { ok: false, blocages };
  return { ok: true, premier: eleves[0].nom, premierIndex: eleves[0].index, nombre: eleves.length };
}

// Associe chaque ligne de la page à un élève du carnet ; le moindre écart va dans les blocages.
function apparierEleves(lignes, elevesCarnet, blocages) {
  const eleves = elevesCarnet.map((el, i) => ({
    ...el,
    rang: i,
    affiche: `${el.nom} ${el.prenom}`.trim(),
    mots: motsDuNom(`${el.nom} ${el.prenom}`),
  }));
  const reconnus = new Map();
  const lignesEleves = [];
  let effectifPage = null;

  lignes.forEach((ligne) => {
    const technique = ligneTechnique(ligne.nom);
    if (technique) {
      if (technique.sorte === 'effectif') effectifPage = technique.nombre;
      return;
    }
    if (!ligne.nom) return;

    const mots = motsDuNom(ligne.nom);
    const candidats = candidatsPourNom(mots, eleves);

    if (candidats.length === 0) {
      blocages.push(`Inconnu dans le carnet : ${ligne.nom}`);
    } else if (candidats.length > 1) {
      blocages.push(`Plusieurs élèves possibles pour : ${ligne.nom}`);
    } else if (reconnus.has(candidats[0].rang)) {
      blocages.push(`Élève trouvé deux fois dans la grille : ${candidats[0].affiche}`);
    } else {
      reconnus.set(candidats[0].rang, ligne);
      lignesEleves.push({ index: ligne.index, nom: ligne.nom, eleve: candidats[0] });
    }
  });

  eleves
    .filter((el) => !reconnus.has(el.rang))
    .forEach((el) => blocages.push(`Pas dans la grille : ${el.affiche}`));

  if (effectifPage !== null && effectifPage !== eleves.length) {
    blocages.push(`École Directe annonce ${effectifPage} élèves, le carnet en a ${eleves.length}.`);
  }

  lignesEleves.sort((a, b) => a.index - b.index);
  return { lignesEleves, effectifPage };
}

// Page des appréciations : une zone par élève. Le panneau retrouve le texte d'après le nom affiché sur la ligne.
function rapprocherAppreciations(lecture, carnet) {
  const blocages = [];
  if (!lecture.table) {
    return { ok: false, blocages: ['Ouvre la page de saisie des appréciations, dans le carnet de notes d’École Directe.'] };
  }
  if (!lecture.lignes.length) blocages.push('Aucune zone d’appréciation trouvée : mets à jour l’extension.');
  if (lecture.lignes.some((l) => !l.nom)) blocages.push('Une ligne n’a pas de nom lisible.');
  const { lignesEleves } = apparierEleves(lecture.lignes, carnet.eleves, blocages);
  if (blocages.length) return { ok: false, blocages };
  return {
    ok: true,
    nombre: lignesEleves.length,
    sansTexte: lignesEleves.filter((l) => !String(l.eleve.appreciation || '').trim()).length,
    tropLongs: lecture.limite
      ? lignesEleves.filter((l) => String(l.eleve.appreciation || '').trim().length > lecture.limite).length
      : 0,
    eleves: lignesEleves.map((l) => ({ nom: l.nom, texte: String(l.eleve.appreciation || '').trim() })),
  };
}

function rapprocher(lecture, carnet) {
  const blocages = [];
  const t = lecture.technique;

  if (t.grilles !== 1) blocages.push('Grille introuvable : ouvre un devoir. Si tu y es déjà, mets à jour l’extension.');
  if (!t.fin) blocages.push("Le bas de la grille n'a pas été atteint.");
  if (t.debutManquant) blocages.push('Le début de la liste semble manquer.');
  if (t.trous) blocages.push('Des lignes de la grille n’ont pas été lues.');
  if (t.conflits) blocages.push('La lecture de la grille est incohérente : recommence.');

  const { lignesEleves, effectifPage } = apparierEleves(lecture.lignes, carnet.eleves, blocages);

  // Le collage remplit des lignes qui se suivent : aucune ligne ne doit couper la liste.
  const coupee = lignesEleves.some((l, i) => i > 0 && l.index !== lignesEleves[i - 1].index + 1);
  if (coupee) blocages.push('La liste des élèves est coupée par une autre ligne : collage impossible.');

  if (blocages.length) return { ok: false, blocages, effectifPage };

  // École Directe refuse les codes collés : leur case reste vide et ils se tapent à la main.
  const nonReconnues = lignesEleves.filter(
    (l) => l.eleve.note !== '' && !TOUCHES_CODES[l.eleve.note] && !/^\d+([,.]\d+)?$/.test(l.eleve.note)
  );
  if (nonReconnues.length) {
    return {
      ok: false,
      blocages: nonReconnues.map((l) => `Note non reconnue pour : ${l.nom}`),
      effectifPage,
    };
  }

  return {
    ok: true,
    colonne: lignesEleves.map((l) => (TOUCHES_CODES[l.eleve.note] ? '' : l.eleve.note)).join('\n'),
    premier: lignesEleves[0].nom,
    premierIndex: lignesEleves[0].index,
    nombre: lignesEleves.length,
    effectifPage,
    vides: lignesEleves.filter((l) => l.eleve.note === '').length,
    aCompleter: lignesEleves
      .filter((l) => TOUCHES_CODES[l.eleve.note])
      .map((l) => ({ nom: l.nom, touche: TOUCHES_CODES[l.eleve.note], index: l.index })),
  };
}
