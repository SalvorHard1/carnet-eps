// Lecture seule, sur la page de saisie des appréciations : lit les noms des élèves pour les comparer au carnet.
// Ne lit ni les notes ni les textes (seulement si une zone est vide ou non) ; n'écrit rien, ne clique sur rien, n'envoie rien.
(() => {
  'use strict';

  const nettoyer = (texte) => (texte || '').replace(/\s+/g, ' ').trim();
  const table = document.querySelector('#table-saisie-appreciation');
  if (!table) return { table: false, lignes: [], remplies: 0, periodes: [], reperes: [] };

  const lignes = [...table.querySelectorAll('tbody tr')].filter((l) => l.querySelector('textarea'));
  const periodes = [
    ...new Set(
      [...document.querySelectorAll('button.dropdown-toggle')]
        .map((b) => nettoyer(b.innerText).match(/^(trimestre|semestre)\s*(\d)$/i))
        .filter(Boolean)
        .map((m) => m[1][0].toUpperCase() + m[2])
    ),
  ];

  // Repères dont l'extension a besoin : s'il en manque un, École Directe a sans doute changé.
  const reperes = [];
  if (!lignes.length) reperes.push('zones');
  if (!periodes.length) reperes.push('periode');
  // Compteur « 0 / 250 » à côté de chaque zone : seule la limite est gardée.
  const limite = Number(lignes[0]?.querySelector('textarea').closest('td')?.innerText.match(/\d+\s*\/\s*(\d+)/)?.[1]) || null;
  if (lignes.length && !limite) reperes.push('limite');
  if (!document.querySelector('#btn-bas-enregistrer')) reperes.push('enregistrer');

  return {
    table: true,
    lignes: lignes.map((l, index) => ({ index, nom: nettoyer(l.cells[0]?.innerText) })),
    remplies: lignes.filter((l) => l.querySelector('textarea').value.trim() !== '').length,
    periodes,
    limite,
    reperes,
  };
})();
